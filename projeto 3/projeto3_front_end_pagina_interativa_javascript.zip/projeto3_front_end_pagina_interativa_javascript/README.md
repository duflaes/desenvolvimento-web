# Projeto 3: Painel Interativo com JavaScript

## Tema
Painel Interativo de Orientação Front-End com estética **Frutiger Aero**, suporte a temas dinâmicos (Claro Pastel e Escuro Neon) e animações suaves de estrelinhas.

## Integrantes
* Eduarda Flausino

## Divisão das Tarefas
* **Integrante 1:** Estrutura HTML semântica (`header`, `main`, `footer`), formulário e acessibilidade dos campos.
* **Integrante 2:** Identidade visual Frutiger Aero no CSS, responsividade, efeitos de vidro translúcido nos botões e temas claro/escuro.
* **Integrante 3:** Lógica em JavaScript, manipulação do DOM, eventos de clique, áudio interativo, validações (`trim`), tomada de decisão (`switch`) e animação de estrelas no canvas.

## Comandos JavaScript Utilizados
* `document.getElementById` e `document.querySelector`: Utilizados para localizar e capturar os elementos do formulário e botões no DOM.
* `const` e `let`: Declaração de variáveis e constantes do programa.
* `addEventListener('click', ...)`: Executa ações dinâmicas de escuta de eventos ao interagir com os botões.
* `value.trim()`: Realiza a leitura e limpeza de espaços em branco nos inputs de texto.
* `switch`: Estrutura condicional para direcionar mensagens personalizadas conforme a área escolhida.
* Template strings (`` `${nome}` ``): Interpolação dinâmica de variáveis dentro das mensagens.
* `textContent`: Insere o resultado processado diretamente na página de forma segura.
* `classList.toggle`: Alternância dinâmica entre as classes de tema claro e escuro.
*