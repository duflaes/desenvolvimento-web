// Função para gerar o som de clique (beep curto) via Web Audio API
function tocarSomClique() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();

        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(600, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(200, audioCtx.currentTime + 0.08);

        gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.08);

        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 0.08);
    } catch (e) {
        console.log("Áudio aguardando interação.");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    // Animação das estrelinhas caindo no canvas
    const canvas = document.getElementById("starfall-canvas");
    if (canvas) {
        const ctx = canvas.getContext("2d");
        let largura = (canvas.width = window.innerWidth);
        let altura = (canvas.height = window.innerHeight);

        window.addEventListener("resize", () => {
            largura = canvas.width = window.innerWidth;
            altura = canvas.height = window.innerHeight;
        });

        const estrelas = Array.from({ length: 45 }, () => ({
            x: Math.random() * largura,
            y: Math.random() * altura,
            tamanho: Math.random() * 3 + 1,
            velocidade: Math.random() * 1 + 0.5,
            brilho: Math.random()
        }));

        function animarEstrelas() {
            ctx.clearRect(0, 0, largura, altura);
            ctx.fillStyle = "rgba(255, 255, 255, 0.8)";

            estrelas.forEach(e => {
                ctx.beginPath();
                ctx.arc(e.x, e.y, e.tamanho, 0, Math.PI * 2);
                ctx.fill();

                e.y += e.velocidade;
                if (e.y > altura) {
                    e.y = 0;
                    e.x = Math.random() * largura;
                }
            });

            requestAnimationFrame(animarEstrelas);
        }
        animarEstrelas();
    }

    // Som em todos os botões
    const botoes = document.querySelectorAll("button");
    botoes.forEach(botao => {
        botao.addEventListener("click", () => {
            tocarSomClique();
        });
    });

    // Funcionalidade do Botão Alternar Tema (Escuro Neon vs Rosa/Roxo)
    const btnTema = document.getElementById("btn-tema");
    let modoNeon = false;
    if (btnTema) {
        btnTema.addEventListener("click", () => {
            modoNeon = !modoNeon;
            if (modoNeon) {
                document.body.style.background = "linear-gradient(135deg, #050505 0%, #1a0026 50%, #2b0033 100%)";
                document.body.style.boxShadow = "inset 0 0 100px rgba(255, 0, 128, 0.2)";
            } else {
                document.body.style.background = "linear-gradient(135deg, #d870ad 0%, #b862ce 50%, #764ba2 100%)";
                document.body.style.boxShadow = "none";
            }
        });
    }

    // Dicionário com orientações exclusivas e detalhadas para cada opção escolhida
    const orientacoesPorArea = {
        "html": "Foque em criar estruturas semânticas limpas, organizando bem as tags do cabeçalho, seções e formulários para garantir máxima acessibilidade.",
        "css": "Explore o uso de variáveis CSS, Flexbox, efeitos de transparência (backdrop-filter) e Media Queries para deixar seu layout responsivo e moderno.",
        "js": "Pratique a manipulação dinâmica do DOM, tratamento de eventos e funções assíncronas para criar páginas verdadeiramente interativas.",
        "logica": "Treine algoritmos resolvendo problemas passo a passo, estruturando condicionais e laços de repetição de forma eficiente.",
        "geral": "Continue praticando pequenos projetos completos, integrando HTML, CSS e JavaScript incrementalmente a cada passo."
    };

    // Funcionalidade do Botão Gerar Orientação
    const btnGerar = document.getElementById("btn-gerar");
    const inputNome = document.getElementById("nome");
    const selectInteresse = document.getElementById("interesse");
    const divResultado = document.getElementById("resultado");

    if (btnGerar) {
        btnGerar.addEventListener("click", (e) => {
            e.preventDefault();
            tocarSomClique();

            const nome = inputNome && inputNome.value.trim() !== "" ? inputNome.value : "Estudante";
            const opcaoSelecionada = selectInteresse ? selectInteresse.value.toLowerCase() : "";

            // Busca a orientação correspondente ou usa a geral caso não encontre a chave exata
            let mensagemOrientacao = orientacoesPorArea["geral"];
            
            for (let chave in orientacoesPorArea) {
                if (opcaoSelecionada.includes(chave)) {
                    mensagemOrientacao = orientacoesPorArea[chave];
                    break;
                }
            }

            if (divResultado) {
                divResultado.innerHTML = `Olá, <strong>${nome}</strong>!<br><br>${mensagemOrientacao}`;
            }
        });
    }
});